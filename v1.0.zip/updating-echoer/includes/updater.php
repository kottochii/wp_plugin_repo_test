<?php

/**
 * Checks for updates
 * @return false|array Version of the new update or false
 */
function check_for_updates()
{
    $remote = wp_remote_get(UPDATING_REPO_ORIGIN . 'versions.json', array(
        'method' => 'GET'
    ));
    if(is_wp_error( $remote ))
    {
        echo '<b>WARNING FROM UPDATER:</b> wp_error received while fetching updates';
    }
    elseif( $remote['response']['code'] == 200 )
    {
        // attempt decoding body
        try
        {
            // decode body
            $body = json_decode($remote['body'], true, 4);
        }
        // it might fail with PHP exception
        catch(Exception $e)
        {
            echo '<b>WARNING FROM UPDATER:</b> Could not get updates';
            return false;
        }
        
        // check the legitimacy of versions.json
        if(empty($body['latest']) || empty($body['versions']))
        {
            echo '<b>WARNING FROM UPDATER:</b> versions.json is invalid.';
        }
        else
        {
            // if versions are different 
            if($body['latest'] !== UE_CURRENT_VERSION)
            {
                // check that the latest version is to be found at all
                if(!empty($body['versions'][ $body['latest'] ]))
                {
                    return  empty($body['versions'][ $body['latest'] ]['address'])?
                            false:
                            ['address' => UPDATING_REPO_ORIGIN . $body['versions'][ $body['latest'] ]['address'], 'version' => $body['latest']];
                }
                else echo '<b>WARNING FROM UPDATER:</b> the link for the oldest version is not in versions.json';
            }
        }
    }
    else echo '<b>WARNING FROM UPDATER:</b> response did not return 200.';
    return false;
}

function pl_bs($result, $action, $args)
{
    //ob_end_clean();
    if($action !== 'plugin_information')
    {
        echo '<h1>Not plugin information lol.</h1>'; 
        return $result;
    }

    //var_dump( $result, $action, $args );
    /* 
    add_action('admin_footer', function() {
        echo '<h1>PLUGIN INFORMATION QUERIED</h1>';
    }); */
    var_dump($result, $args);
    return $result;
}

add_filter('plugins_api', 'pl_bs', 40,3);

function transient_update($value)
{

    // do nothing if this is not the valid call and our plugin is not checked
    if((empty($value->checked)||empty($value->checked[UE_SLUG_PATH])))
        return false;
    if(!empty($value->response[UE_SLUG_PATH]))
        return false;

    // check for updates
    $checker = check_for_updates();
    if($checker === false)
        return false;
    
    // tell WP that the plugin can be updated
    $result = new stdClass();
    $result->slug = UE_SLUG;
    $result->plugin = UE_SLUG_PATH;
    $result->new_version = $checker['version'];
    $result->package = $checker['address'];

    $value->response[UE_SLUG_PATH] = $result;

    return $value;
}

add_filter('site_transient_update_plugins', 'transient_update');