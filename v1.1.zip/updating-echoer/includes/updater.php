<?php
namespace UE;

    class Updater
    {
        private $current_version;
        static $repo_body = null;
        /**
         * Queries the repository
         * @return false|array The content of versions.json or false if error occured.
         */
        static function query_repo()
        {
            // make sure not to overquery the origin
            if(self::$repo_body !== null)
                return self::$repo_body;
            $remote = wp_remote_get(UPDATING_REPO_ORIGIN . 'versions.json', array(
                'method' => 'GET'
            ));
            if(is_wp_error( $remote ))
            {
                echo '<!-- <b>WARNING FROM UPDATER:</b> wp_error received while fetching updates -->';
            }
            elseif( $remote['response']['code'] == 200 )
            {
                // attempt decoding body
                try
                {
                    // decode body
                    $body = json_decode($remote['body'], true, 4);
                }
                // it might fail with PHP exception
                catch(Exception $e)
                {
                    echo '<!-- Could not get updates for custom repo. -->';
                    return false;
                }

                // checks the legitimacy of the file: if version and latest are present, then it is possibly legit
                // otherwise not
                // in case of repo being reused by something else
                if (!empty($body['versions'])&&!empty($body['latest']))
                {
                    return self::$repo_body = $body;
                }
                else return false;
            }
            else echo '<!-- while querying versions.json, response did not return 200. -->';
            return false;
        }

        /**
         * Filter handler for the description of the plugin.
         * @param $result
         * @param $action
         * @param $args
         */
        public function get_description($result, $action, $args)
        {
            // only handle for plugin_information
            if($action !== 'plugin_information')
                return $result;


            // do nothing if it is not our plugin
            if( UE_SLUG !== $args->slug ) {
                return $result;
            }
            // get the body from the repo
            $body = self::query_repo();

            // if there is a problem with repo, do nothing
            // comment that there is a problem still
            if($body === false)
            {
                echo '<!-- There has been an error while getting description for plugin with custom repo.  -->';
                return $result;
            }

            // at this point, remote is good to work with

            if(!empty($body['versions'][ $body['latest'] ]) && !empty($body['name']))
            {
                // constructing a new class first
                $result = new \stdClass();
                // directly copy fields from remote:
                // name
                $result->name = $body['name'];
                // author
                if(!empty($body['author']))
                    $result->author = $body['author'];
                // latest version
                if(!empty($body['latest']))
                    $result->version = $body['latest'];
                // published time
                if(!empty($body['versions'][ $body['latest'] ]['published']))
                    $result->last_updated = $body['versions'][ $body['latest'] ]['published'];
                // create array for sections
                $result->sections = [];
                // populate with information from the remote
                if(!empty($body['versions'][ $body['latest'] ]['description']))
                    $result->sections['description'] = $body['versions'][ $body['latest'] ]['description'];
            }
            // return $result regardless if it is in the same state as it was before or not
            return $result;
        }

        /**
         * Queries the remote for new versions
         * @return array|false {"version","address"} of new update or false if update not found
         */
        function check_for_updates()
        {
            // query the repo
            $body = self::query_repo();
            // check that the latest version is actually greater than current
            if(!version_compare($body['latest'], $this->current_version, '>'))
            {
                // otherwise return false;
                return false;
            }

            // now we need to get the address of the new version if it exists at all
            if(empty($body['versions'][ $body['latest'] ])||empty($body['versions'][ $body['latest'] ]['address']))
                // no address, everything is horrible
                return false;
            
            else
            {
                return [
                    // concat origin and the address from the JSON
                    'address' => UPDATING_REPO_ORIGIN . $body['versions'][ $body['latest'] ]['address'],
                    // add version
                    'version' => $body['latest']
                ];
            }
        }

        /**
         * Filter handler for the transient update of the plugin
         */
        public function transient_update($value)
        {

            // do nothing if this is not the valid call and our plugin is not checked
            if((empty($value->checked)||empty($value->checked[UE_SLUG_PATH])))
                return $value;
            if(!empty($value->response[UE_SLUG_PATH]))
                return $value;
            // check for updates
            $checker = $this->check_for_updates();
            if($checker === false)
                return $value;
        
            // tell WP that the plugin can be updated
            $result = new \stdClass();
            $result->slug = UE_SLUG;
            $result->plugin = UE_SLUG_PATH;
            $result->new_version = $checker['version'];
            $result->package = $checker['address'];

            $value->response[UE_SLUG_PATH] = $result;

            return $value;
        }

        /**
         * @param string Current version of the plugin
         */
        public function __construct($version)
        {
            $this->current_version = $version;
            // add hooks
            add_filter('plugins_api', [$this, 'get_description'], 40,3);
            add_filter('site_transient_update_plugins', [$this, 'transient_update']);
        }
    }

$ue_updater = new \UE\Updater(UE_CURRENT_VERSION);