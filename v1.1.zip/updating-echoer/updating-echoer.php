<?php

/**
 * Plugin name: Updating echoer
 * Version: 1.0
 */

define('UPDATING_REPO_ORIGIN','https://kottochii.github.io/wp_plugin_repo_test/');

define( 'UE_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'UE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define('UE_CURRENT_VERSION', '1.1');
define('UE_SLUG','updating-echoer');
define('UE_SLUG_PATH',UE_SLUG . '/' . UE_SLUG . '.php');

require_once UE_PLUGIN_PATH . 'includes/updater.php';

function echo_footer()
{
    echo '<p>Footer ok. ' . UE_CURRENT_VERSION . '</p>';
}

add_action('wp_footer', 'echo_footer', 10, 0);

